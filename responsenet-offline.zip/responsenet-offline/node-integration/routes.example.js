// Example of wiring Offline Mode into an emergency-request endpoint.
// This is a template to copy the pattern from — splice the offline
// branch into your ACTUAL existing route rather than replacing it
// wholesale, since your current route almost certainly already does
// useful things (auth, validation, existing cloud AI calls) this
// doesn't know about.

const express = require("express");
const multer = require("multer");
const { randomUUID } = require("crypto");

const { isOnline } = require("./offlineMode");
const { transcribeAudio, triageText } = require("./aiClient");
const { enqueueRequest, getAllForCoordinatorView } = require("./localStore");

const router = express.Router();
const upload = multer({ storage: multer.memoryStorage() });

// POST /api/emergency-request  (multipart/form-data, field name "audio")
router.post("/emergency-request", upload.single("audio"), async (req, res) => {
  try {
    if (isOnline()) {
      // --- YOUR EXISTING ONLINE PATH GOES HERE ---
      // e.g. call your current cloud STT/triage/API, save to your real DB, etc.
      // return res.status(201).json(existingResult);
      return res.status(501).json({ error: "Wire in your existing online path here." });
    }

    // --- OFFLINE PATH ---
    if (!req.file) {
      return res.status(400).json({ error: "audio file required" });
    }

    const transcript = await transcribeAudio(req.file.buffer, req.file.originalname);
    const triage = await triageText(transcript);

    const id = randomUUID();
    enqueueRequest({ id, transcript, triage });

    return res.status(202).json({
      id,
      status: "queued_offline",
      transcript,
      triage,
      message: "Saved locally. Will sync automatically once connectivity returns.",
    });
  } catch (err) {
    console.error("emergency-request failed:", err);
    return res.status(500).json({ error: "Failed to process request", detail: err.message });
  }
});

// GET /api/coordinator/requests — works fully offline, reads local store directly
router.get("/coordinator/requests", (req, res) => {
  const onlyUnsynced = req.query.unsynced === "true";
  res.json(getAllForCoordinatorView({ onlyUnsynced }));
});

module.exports = router;
