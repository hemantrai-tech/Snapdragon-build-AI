// Background sync: flushes queued offline requests to your real cloud
// backend as soon as connectivity is confirmed. Idempotent by design —
// safe to retry the same row multiple times if a sync attempt fails
// partway through (e.g. connection drops mid-request).

const { isOnline, onChange } = require("./offlineMode");
const { getUnsyncedRequests, markSynced, markSyncFailed } = require("./localStore");

const CLOUD_INGEST_URL =
  process.env.RESPONSENET_CLOUD_INGEST_URL ||
  "https://api.your-responsenet-domain.example/emergency-requests";
const CLOUD_API_KEY = process.env.RESPONSENET_CLOUD_API_KEY;

async function pushOne(row) {
  const res = await fetch(CLOUD_INGEST_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      ...(CLOUD_API_KEY ? { Authorization: `Bearer ${CLOUD_API_KEY}` } : {}),
    },
    body: JSON.stringify({
      // idempotency_key lets your backend safely dedupe if this row
      // gets pushed twice (e.g. connectivity drops after the cloud
      // accepted it but before we hear back).
      idempotency_key: row.id,
      created_at: row.created_at,
      transcript: row.transcript,
      severity: row.severity,
      category: row.category,
      location_hint: row.location_hint,
      people_affected: row.people_affected,
      summary: row.summary,
      source: "offline_mode_sync",
    }),
  });
  if (!res.ok) {
    throw new Error(`Cloud ingest returned ${res.status}: ${await res.text()}`);
  }
}

async function flushQueue() {
  if (!isOnline()) return { pushed: 0, failed: 0 };

  const pending = getUnsyncedRequests(50);
  let pushed = 0;
  let failed = 0;

  for (const row of pending) {
    try {
      await pushOne(row);
      markSynced(row.id);
      pushed += 1;
    } catch (err) {
      markSyncFailed(row.id, err.message);
      failed += 1;
      // Stop this pass on the first failure — likely means connectivity
      // dropped again mid-flush, no point hammering the rest of the queue.
      break;
    }
  }
  return { pushed, failed };
}

function startSyncEngine({ intervalMs = 10000 } = {}) {
  // Try immediately whenever we transition to online...
  onChange((nowOnline) => {
    if (nowOnline) flushQueue();
  });
  // ...and keep retrying periodically in case some rows failed.
  return setInterval(flushQueue, intervalMs);
}

module.exports = { flushQueue, startSyncEngine };
