// Client for the local Python sidecar (python-sidecar/app.py).
// This always talks to localhost — it works identically whether the
// machine is online or offline, which is the whole point.

const FormData = require("form-data");

const SIDECAR_BASE_URL = process.env.AI_SIDECAR_URL || "http://127.0.0.1:8765";

async function transcribeAudio(audioBuffer, filename = "audio.wav") {
  const form = new FormData();
  form.append("audio", audioBuffer, filename);

  const res = await fetch(`${SIDECAR_BASE_URL}/transcribe`, {
    method: "POST",
    body: form,
    headers: form.getHeaders(),
  });
  if (!res.ok) {
    throw new Error(`Sidecar transcribe failed: ${res.status} ${await res.text()}`);
  }
  const { text } = await res.json();
  return text;
}

async function triageText(transcript) {
  const res = await fetch(`${SIDECAR_BASE_URL}/triage`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ transcript }),
  });
  if (!res.ok) {
    throw new Error(`Sidecar triage failed: ${res.status} ${await res.text()}`);
  }
  return res.json(); // { severity, category, location_hint, people_affected, summary }
}

async function summarizeRequests(requestList) {
  const res = await fetch(`${SIDECAR_BASE_URL}/summarize`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ requests: requestList }),
  });
  if (!res.ok) {
    throw new Error(`Sidecar summarize failed: ${res.status} ${await res.text()}`);
  }
  return res.json(); // { prioritized_order, duplicate_groups, coordinator_brief }
}

async function sidecarHealthy() {
  try {
    const res = await fetch(`${SIDECAR_BASE_URL}/health`, { signal: AbortSignal.timeout(1500) });
    return res.ok;
  } catch {
    return false;
  }
}

module.exports = { transcribeAudio, triageText, summarizeRequests, sidecarHealthy };
