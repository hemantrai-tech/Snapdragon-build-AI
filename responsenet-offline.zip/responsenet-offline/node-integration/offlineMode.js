// Connectivity detection for ResponseNet Offline Mode.
//
// Don't trust navigator.onLine equivalents or a bare DNS check alone —
// a machine can have a Wi-Fi link but no route to your actual backend
// (this is exactly the "connectivity is technically up but useless"
// case from local outages/congestion). We check reachability of your
// OWN backend's health endpoint, with a short timeout, so "online"
// here specifically means "can currently reach ResponseNet's cloud".

const CLOUD_HEALTH_URL =
  process.env.RESPONSENET_CLOUD_HEALTH_URL || "https://api.your-responsenet-domain.example/health";
const CHECK_TIMEOUT_MS = 2500;
const CHECK_INTERVAL_MS = 15000;

let isOnlineState = false;
let listeners = [];

async function checkOnce() {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), CHECK_TIMEOUT_MS);
  try {
    const res = await fetch(CLOUD_HEALTH_URL, { signal: controller.signal });
    const nowOnline = res.ok;
    setState(nowOnline);
    return nowOnline;
  } catch (_err) {
    setState(false);
    return false;
  } finally {
    clearTimeout(timeout);
  }
}

function setState(nowOnline) {
  const changed = nowOnline !== isOnlineState;
  isOnlineState = nowOnline;
  if (changed) {
    for (const fn of listeners) fn(isOnlineState);
  }
}

function isOnline() {
  return isOnlineState;
}

function onChange(fn) {
  listeners.push(fn);
  return () => {
    listeners = listeners.filter((l) => l !== fn);
  };
}

function startPolling() {
  checkOnce();
  return setInterval(checkOnce, CHECK_INTERVAL_MS);
}

module.exports = { isOnline, checkOnce, onChange, startPolling };
