// Local-first storage for ResponseNet Offline Mode.
//
// Everything captured while offline lands here first. The sync engine
// (syncEngine.js) later pushes unsynced rows to your real cloud
// backend and marks them synced. Nothing here ever blocks on network.
//
// npm install better-sqlite3

const path = require("path");
const Database = require("better-sqlite3");

const DB_PATH = process.env.OFFLINE_DB_PATH || path.join(__dirname, "offline-store.db");

const db = new Database(DB_PATH);
db.pragma("journal_mode = WAL");

db.exec(`
  CREATE TABLE IF NOT EXISTS emergency_requests (
    id TEXT PRIMARY KEY,
    created_at TEXT NOT NULL,
    transcript TEXT,
    severity TEXT,
    category TEXT,
    location_hint TEXT,
    people_affected INTEGER,
    summary TEXT,
    raw_triage_json TEXT,
    synced INTEGER NOT NULL DEFAULT 0,
    sync_attempts INTEGER NOT NULL DEFAULT 0,
    last_sync_error TEXT
  );

  CREATE INDEX IF NOT EXISTS idx_emergency_requests_synced
    ON emergency_requests (synced);
`);

function enqueueRequest({ id, transcript, triage }) {
  const stmt = db.prepare(`
    INSERT INTO emergency_requests
      (id, created_at, transcript, severity, category, location_hint,
       people_affected, summary, raw_triage_json, synced)
    VALUES (@id, @created_at, @transcript, @severity, @category, @location_hint,
            @people_affected, @summary, @raw_triage_json, 0)
  `);
  stmt.run({
    id,
    created_at: new Date().toISOString(),
    transcript,
    severity: triage.severity ?? null,
    category: triage.category ?? null,
    location_hint: triage.location_hint ?? null,
    people_affected: triage.people_affected ?? null,
    summary: triage.summary ?? null,
    raw_triage_json: JSON.stringify(triage),
  });
  return id;
}

function getUnsyncedRequests(limit = 50) {
  return db
    .prepare(
      `SELECT * FROM emergency_requests WHERE synced = 0 ORDER BY created_at ASC LIMIT ?`
    )
    .all(limit);
}

function markSynced(id) {
  db.prepare(`UPDATE emergency_requests SET synced = 1, last_sync_error = NULL WHERE id = ?`).run(
    id
  );
}

function markSyncFailed(id, errorMessage) {
  db.prepare(
    `UPDATE emergency_requests
       SET sync_attempts = sync_attempts + 1, last_sync_error = ?
     WHERE id = ?`
  ).run(String(errorMessage).slice(0, 500), id);
}

function getAllForCoordinatorView({ onlyUnsynced = false } = {}) {
  const query = onlyUnsynced
    ? `SELECT * FROM emergency_requests WHERE synced = 0 ORDER BY created_at DESC`
    : `SELECT * FROM emergency_requests ORDER BY created_at DESC`;
  return db.prepare(query).all();
}

module.exports = {
  db,
  enqueueRequest,
  getUnsyncedRequests,
  markSynced,
  markSyncFailed,
  getAllForCoordinatorView,
};
