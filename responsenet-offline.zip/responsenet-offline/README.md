# ResponseNet Offline Mode

On-device AI layer that keeps ResponseNet functional with zero internet:
voice-to-text triage, local-first storage, and background sync — for the
Qualcomm Snapdragon AI Lab Build & Present Challenge.

## Architecture

```
Your Node.js ResponseNet app  <--HTTP, localhost-->  Python AI sidecar (FastAPI)
        |                                                   |
        | writes to                                         | runs
        v                                                   v
  offline-store.db (SQLite)                    Whisper STT + triage LLM
        |                                        (Hexagon NPU on the real device)
        | flushed by syncEngine.js
        v
  Your existing cloud backend (only when online)
```

The Python sidecar is the piece that actually touches the NPU (Whisper
STT + Genie/on-device LLM). It's a separate process from your Node app
on purpose — Qualcomm's model tooling (`qai_hub_models`, ONNX Runtime
QNN EP, Genie) is Python, and this way you don't have to port any of it
to JS. Node just calls `localhost:8765` instead of your cloud API when
it's offline.

## What's real vs. what you still need to fill in

**Works today, on any machine, no NPU required** (this is deliberate —
build and demo the whole flow now, swap the two NPU-specific pieces in
last):
- FastAPI sidecar with `/transcribe`, `/triage`, `/summarize`
- Whisper CPU backend (`stt_backend.py`, `openai-whisper` package)
- Triage + summarization prompts, JSON parsing/repair
- SQLite local queue, connectivity detection, background sync engine
- Example Express route showing the offline branch

**You need to fill in on the Snapdragon PC before submitting** (marked
with `TODO` in the code — see `stt_backend.py` and `llm_backend.py`
docstrings for exact commands/links):
1. Export Whisper to ONNX via `qai_hub_models` and wire it into
   `WhisperQNNBackend._transcribe_qnn`, using Qualcomm's own
   `whisper_windows_py` sample app as the reference implementation
   (link is in the docstring) rather than reimplementing the
   mel-spectrogram/decoder loop from scratch.
2. Stand up Genie's `GenieAPIService` (or your chosen on-device LLM
   runtime) and point `LLM_BASE_URL` / `LLM_MODEL` at it. Until then,
   point it at a local Ollama instance for development.
3. Point `RESPONSENET_CLOUD_HEALTH_URL` and
   `RESPONSENET_CLOUD_INGEST_URL` at your real backend's endpoints.

## Setup

### Python sidecar
```bash
cd python-sidecar
python -m venv .venv && source .venv/bin/activate   # or .venv\Scripts\activate on Windows
pip install -r requirements.txt

# Dev/testing (CPU, no NPU needed):
export STT_BACKEND=cpu
export LLM_BASE_URL=http://localhost:11434/v1   # e.g. Ollama
export LLM_MODEL=llama3.2:3b

uvicorn app:app --host 127.0.0.1 --port 8765 --reload
```

Test it directly before wiring up Node:
```bash
curl -X POST http://127.0.0.1:8765/triage \
  -H "Content-Type: application/json" \
  -d '{"transcript": "Water is rising fast near the bridge on MG Road, my grandmother cannot walk, we need help now"}'
```

### Node integration
```bash
# from your ResponseNet repo root
cp -r node-integration/*.js  <wherever you keep server modules>/
npm install better-sqlite3 form-data multer
```

Then in your existing server file:
```js
const { startPolling } = require("./offlineMode");
const { startSyncEngine } = require("./syncEngine");
const offlineRoutes = require("./routes.example"); // merge into your real router

startPolling();
startSyncEngine();
app.use("/api", offlineRoutes);
```

Set the env vars Node needs (`.env` or your existing config):
```
RESPONSENET_CLOUD_HEALTH_URL=https://<your-api>/health
RESPONSENET_CLOUD_INGEST_URL=https://<your-api>/emergency-requests
RESPONSENET_CLOUD_API_KEY=<if you use one>
AI_SIDECAR_URL=http://127.0.0.1:8765
```

## Demoing the "connectivity killed" scenario

This is the clip that should anchor your submission video:
1. Start both services normally, confirm `isOnline()` is true.
2. Disconnect Wi-Fi / disable the network adapter.
3. Submit a voice request through your app's normal UI — it should
   get a `202 queued_offline` response and show up in
   `GET /api/coordinator/requests?unsynced=true`.
4. Reconnect Wi-Fi. Within `syncEngine`'s poll interval, the row
   should flip to synced and land in your cloud backend.
5. Pull the Whisper/triage latency numbers from your `qai_hub_models`
   export step (or add simple timing around the `/transcribe` and
   `/triage` calls) for the "Technical Implementation" writeup —
   judges want a number, not just "it works offline."

## Files

```
python-sidecar/
  app.py               FastAPI endpoints: /transcribe /triage /summarize
  stt_backend.py        Whisper: CPU backend (works now) + QNN backend (TODO)
  llm_backend.py         OpenAI-compatible client for the triage/summary LLM
  triage_prompts.py       Prompt templates + JSON schemas
  requirements.txt

node-integration/
  localStore.js          SQLite queue: enqueue, unsynced reads, mark-synced
  offlineMode.js          Connectivity polling against your own backend's /health
  aiClient.js             Calls the Python sidecar over localhost
  syncEngine.js           Flushes the queue to your cloud backend when online
  routes.example.js       Example Express route wiring the offline branch in
  package.snippet.json    Dependencies to add to your package.json
```
