"""
Triage/summarization LLM backend for ResponseNet Offline Mode.

Rather than binding to a specific SDK's internal API (which I'd be
guessing at), this talks to a plain OpenAI-compatible chat-completions
endpoint over HTTP. That interface is stable and lets you develop
against a convenient local stand-in today, then point LLM_BASE_URL at
the real thing on the Snapdragon PC without touching this file:

  - Dev/testing today: run Ollama locally (`ollama serve`, e.g. with
    `llama3.2:3b`) and set LLM_BASE_URL=http://localhost:11434/v1
  - Real submission: Qualcomm's Genie can be run as "GenieAPIService",
    which exposes an OpenAI-compatible API for on-device models (Llama
    3, Qwen 3, Gemma 2) served from the Hexagon NPU. Point
    LLM_BASE_URL at wherever that service listens, and LLM_MODEL at
    the model name it reports. Consult Qualcomm's QAI AppBuilder /
    Genie docs for exact setup on your device.

Either way, zero network calls leave the machine — this is a request
to localhost or a LAN-local service, not to the public internet.
"""

import json
import os

import requests


class LLMBackend:
    def __init__(self, base_url: str | None = None, model: str | None = None):
        self.base_url = base_url or os.environ.get(
            "LLM_BASE_URL", "http://localhost:11434/v1"
        )
        self.model = model or os.environ.get("LLM_MODEL", "llama3.2:3b")

    def chat(self, system_prompt: str, user_prompt: str, temperature: float = 0.0) -> str:
        resp = requests.post(
            f"{self.base_url}/chat/completions",
            json={
                "model": self.model,
                "temperature": temperature,
                "messages": [
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt},
                ],
            },
            timeout=30,
        )
        resp.raise_for_status()
        data = resp.json()
        return data["choices"][0]["message"]["content"]

    def chat_json(self, system_prompt: str, user_prompt: str) -> dict:
        """Calls chat() and parses the response as JSON, with one repair
        attempt if the model wraps the JSON in prose or code fences."""
        raw = self.chat(system_prompt, user_prompt, temperature=0.0)
        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            cleaned = raw.strip().strip("`")
            if cleaned.lower().startswith("json"):
                cleaned = cleaned[4:].strip()
            start, end = cleaned.find("{"), cleaned.rfind("}")
            if start != -1 and end != -1:
                return json.loads(cleaned[start : end + 1])
            raise
