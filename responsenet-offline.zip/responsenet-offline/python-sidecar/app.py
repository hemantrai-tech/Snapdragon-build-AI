"""
ResponseNet Offline Mode — local AI sidecar.

Runs alongside your existing Node.js ResponseNet app on the same
Snapdragon-powered HP PC. The Node app calls this over localhost
instead of your cloud AI/API when it detects it's offline (or always,
if you want the NPU path to be the default — your call).

Run:
    uvicorn app:app --host 127.0.0.1 --port 8765

Nothing in this file makes an outbound network call. All state lives
in the request/response cycle; the Node side owns persistence.
"""

import os
import tempfile

from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from llm_backend import LLMBackend
from stt_backend import get_stt_backend
from triage_prompts import (
    SUMMARIZE_SYSTEM_PROMPT,
    TRIAGE_SYSTEM_PROMPT,
    build_summarize_user_prompt,
    build_triage_user_prompt,
)

app = FastAPI(title="ResponseNet Offline Sidecar")

# The Node app runs on a different localhost port — allow it through.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://127.0.0.1:3000"],
    allow_methods=["*"],
    allow_headers=["*"],
)

_stt = None
_llm = LLMBackend()


def get_stt():
    global _stt
    if _stt is None:
        _stt = get_stt_backend()
    return _stt


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/transcribe")
async def transcribe(audio: UploadFile = File(...)):
    suffix = os.path.splitext(audio.filename or "")[1] or ".wav"
    with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as tmp:
        tmp.write(await audio.read())
        tmp_path = tmp.name
    try:
        text = get_stt().transcribe(tmp_path)
    except Exception as exc:  # surfaced to Node as a 500 with detail
        raise HTTPException(status_code=500, detail=f"STT failed: {exc}") from exc
    finally:
        os.unlink(tmp_path)
    return {"text": text}


class TriageRequest(BaseModel):
    transcript: str


@app.post("/triage")
def triage(req: TriageRequest):
    try:
        result = _llm.chat_json(
            TRIAGE_SYSTEM_PROMPT, build_triage_user_prompt(req.transcript)
        )
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Triage failed: {exc}") from exc
    return result


class SummarizeRequest(BaseModel):
    requests: list[dict]


@app.post("/summarize")
def summarize(req: SummarizeRequest):
    if not req.requests:
        return {"prioritized_order": [], "duplicate_groups": [], "coordinator_brief": ""}
    try:
        result = _llm.chat_json(
            SUMMARIZE_SYSTEM_PROMPT, build_summarize_user_prompt(req.requests)
        )
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Summarize failed: {exc}") from exc
    return result
