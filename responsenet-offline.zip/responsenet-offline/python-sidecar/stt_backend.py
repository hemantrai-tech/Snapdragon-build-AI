"""
Speech-to-text backend for ResponseNet Offline Mode.

Two implementations, selected by the STT_BACKEND env var:

  STT_BACKEND=cpu (default) -> plain `openai-whisper` pip package.
      Works on any machine right now, no NPU, no Qualcomm SDK. Use this
      to build and test the rest of the pipeline (triage, storage, sync)
      today, in VS Code, on whatever laptop you're on.

  STT_BACKEND=qnn -> Qualcomm AI Hub Whisper export running on the
      Hexagon NPU via ONNX Runtime's QNN execution provider. This is
      what you actually submit. It only works on the Snapdragon-powered
      HP PC with the Qualcomm AI Runtime (QAIRT) SDK installed.

I'm not guessing at qai_hub_models' exact internal class names here —
that package's API surface changes between versions and I'd rather you
get a working CPU pipeline today than a QNNBackend that silently fails
because I invented a method that doesn't exist. Follow the two TODOs
below using the official export + demo docs:

  1. Export the model (one-time, run in your Python env on the Snapdragon PC):
       pip install "qai_hub_models[whisper_base_en]"
       python -m qai_hub_models.models.whisper_base_en.export \
           --target-runtime onnx --device "Snapdragon X Elite CRD"
     This drops an ONNX encoder + decoder plus profiling numbers
     (latency, memory) you'll want for your submission writeup.

  2. Qualcomm AI Hub Apps ships a ready-made "Whisper Windows" sample app
     (Python, ONNX Runtime + QNN EP) at:
       https://aihub.qualcomm.com/apps/whisper_windows_py
     The fastest path to a correct QNNBackend is to drop that sample's
     inference code into `_transcribe_qnn` below, rather than
     hand-rolling the mel-spectrogram -> encoder -> decoder loop
     yourself.
"""

import os
import tempfile


class STTBackend:
    def transcribe(self, audio_path: str) -> str:
        raise NotImplementedError


class WhisperCPUBackend(STTBackend):
    """Dev/testing backend. Loads once, reused across requests."""

    def __init__(self, model_size: str = "base"):
        import whisper  # openai-whisper package

        self._model = whisper.load_model(model_size)

    def transcribe(self, audio_path: str) -> str:
        result = self._model.transcribe(audio_path)
        return result["text"].strip()


class WhisperQNNBackend(STTBackend):
    """
    Real submission backend: Hexagon NPU via ONNX Runtime QNN EP.
    Fill in _transcribe_qnn per the TODOs in the module docstring above.
    """

    def __init__(self, encoder_path: str, decoder_path: str):
        import onnxruntime as ort

        providers = [
            ("QNNExecutionProvider", {"backend_path": "QnnHtp.dll"}),
            "CPUExecutionProvider",  # falls back automatically if QNN init fails
        ]
        self._encoder = ort.InferenceSession(encoder_path, providers=providers)
        self._decoder = ort.InferenceSession(decoder_path, providers=providers)

    def transcribe(self, audio_path: str) -> str:
        return self._transcribe_qnn(audio_path)

    def _transcribe_qnn(self, audio_path: str) -> str:
        # TODO: port the mel-spectrogram preprocessing + encoder/decoder
        # loop + tokenizer decode from Qualcomm's whisper_windows_py
        # sample app (see module docstring for the link).
        raise NotImplementedError(
            "Wire this up from the Qualcomm Whisper Windows sample app "
            "before switching STT_BACKEND=qnn."
        )


def get_stt_backend() -> STTBackend:
    backend = os.environ.get("STT_BACKEND", "cpu").lower()
    if backend == "qnn":
        return WhisperQNNBackend(
            encoder_path=os.environ["WHISPER_ENCODER_PATH"],
            decoder_path=os.environ["WHISPER_DECODER_PATH"],
        )
    model_size = os.environ.get("WHISPER_CPU_MODEL", "base")
    return WhisperCPUBackend(model_size=model_size)
